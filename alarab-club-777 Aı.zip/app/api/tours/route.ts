import { NextResponse } from "next/server"

export async function GET() {
  const tours = [
    {
      Name: "جولة الأهرامات الكاملة",
      Description: "زيارة شاملة للأهرامات الثلاثة مع ركوب الجمل",
      Phone: "971557119058",
    },
    {
      Name: "جولة سقارة التاريخية",
      Description: "استكشاف مجمع سقارة الأثري مع مرشد متخصص",
      Phone: "971557119058",
    },
    {
      Name: "مغامرة الصحراء",
      Description: "ركوب الخيل والجمال في الصحراء مع العشاء البدوي",
      Phone: "971557119058",
    },
  ]

  return NextResponse.json({ tours })
}
