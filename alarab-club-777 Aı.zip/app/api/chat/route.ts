import { type NextRequest, NextResponse } from "next/server"
import { streamText } from "ai"
import { groq } from "@ai-sdk/groq"

export async function POST(request: NextRequest) {
  try {
    const { message } = await request.json()

    const result = await streamText({
      model: groq("llama-3.1-70b-versatile"),
      system: `أنت مساعد سياحي خبير في منطقة الجيزة والأهرامات في مصر. اسمك العرّاب وأنت تعمل مع AlArab Club 777. 
      
      مهامك:
      - مساعدة السياح في حجز الجولات السياحية
      - تقديم معلومات عن الأهرامات وسقارة
      - ترتيب النقل من وإلى المطار
      - حجز الفنادق العائلية والضيافة العربية
      - تنظيم رحلات ركوب الجمال والخيل
      
      أجب باللغة العربية دائماً وكن مفيداً ومرحباً. اذكر رقم الواتساب للتواصل المباشر عند الحاجة.`,
      prompt: message,
    })

    const fullText = await result.text

    return NextResponse.json({
      reply: fullText,
      success: true,
    })
  } catch (error) {
    console.error("Chat API Error:", error)
    return NextResponse.json(
      {
        error: "حدث خطأ في معالجة الرسالتك. يرجى المحاولة مرة أخرى أو التواصل معنا مباشرة عبر الواتساب.",
        success: false,
      },
      { status: 500 },
    )
  }
}
