import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { message } = await request.json()

    // Simple response for now - you can integrate with OpenAI API later
    const reply = `شكراً لرسالتك: "${message}". نحن هنا لمساعدتك في حجز أفضل الجولات في منطقة الجيزة والأهرامات. يمكنك التواصل معنا عبر واتساب للحصول على عروض مخصصة.`

    return NextResponse.json({ reply })
  } catch (error) {
    return NextResponse.json({ error: "حدث خطأ في معالجة الرسالة" }, { status: 500 })
  }
}
