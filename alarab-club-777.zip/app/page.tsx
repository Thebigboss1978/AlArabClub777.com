"use client"

import { useEffect, useState } from "react"
import Script from "next/script"

export default function GizaPortal() {
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [mode, setMode] = useState("spiritual")
  const [state, setState] = useState({
    phone: "971557119058",
    csv: "https://docs.google.com/spreadsheets/d/e/2PACX-1vT9qkqp2gmx_IIElxTQQiOLF680qe1b4uNhGopZuZhEVxumd-YejBPsHuGiThAWdQzi14hjYAV2rzGb/pub?output=csv",
    aiEndpoint: "",
    offers: [],
    mode: "spiritual",
  })

  useEffect(() => {
    // Initialize the portal after component mounts
    if (typeof window !== "undefined") {
      initializePortal()
    }
  }, [])

  useEffect(() => {
    // Load saved settings
    try {
      const raw = localStorage.getItem("pyramids_settings_v1")
      if (raw) setState(JSON.parse(raw))
    } catch (e) {}
  }, [])

  useEffect(() => {
    // Save settings to localStorage
    localStorage.setItem("pyramids_settings_v1", JSON.stringify(state))
  }, [state])

  const initializePortal = () => {
    initCanvasPortal()
    renderContact()
    renderQR()
    fetchAndRenderOffers()
  }

  const initCanvasPortal = () => {
    const canvas = document.getElementById("scene")
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    let W = 0,
      H = 0,
      DPR = 1
    const glyphs = ["𓂀", "𓆣", "𓋹", "▲", "◈", "•", "✦", "✧"]
    const particles = []

    const resize = () => {
      DPR = Math.min(2, window.devicePixelRatio || 1)
      W = canvas.width = window.innerWidth * DPR
      H = canvas.height = window.innerHeight * DPR
      canvas.style.width = window.innerWidth + "px"
      canvas.style.height = window.innerHeight + "px"
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0)
    }

    window.addEventListener("resize", resize)
    resize()

    // Seed particles
    for (let i = 0; i < 160; i++) {
      particles.push({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        vx: (Math.random() - 0.5) * 0.6,
        vy: (Math.random() - 0.5) * 0.3,
        ch: glyphs[i % glyphs.length],
        s: 10 + Math.random() * 12,
        a: 0.3 + Math.random() * 0.7,
      })
    }

    let t = 0
    const tick = () => {
      requestAnimationFrame(tick)
      t += 0.01
      ctx.clearRect(0, 0, window.innerWidth, window.innerHeight)

      // Subtle radial gradient
      const g = ctx.createRadialGradient(
        window.innerWidth * 0.2,
        window.innerHeight * 0.15,
        100,
        window.innerWidth * 0.6,
        window.innerHeight * 0.6,
        window.innerWidth,
      )
      g.addColorStop(0, "rgba(14,165,233,.03)")
      g.addColorStop(1, "rgba(0,0,0,0)")
      ctx.fillStyle = g
      ctx.fillRect(0, 0, window.innerWidth, window.innerHeight)

      // Draw particles
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      for (const p of particles) {
        p.x += p.vx + Math.sin(t + p.y * 0.002) * 0.2
        p.y += p.vy + Math.cos(t + p.x * 0.002) * 0.1
        if (p.x < -40) p.x = window.innerWidth + 40
        if (p.x > window.innerWidth + 40) p.x = -40
        if (p.y < -40) p.y = window.innerHeight + 40
        if (p.y > window.innerHeight + 40) p.y = -40
        ctx.globalAlpha = p.a * (0.7 + 0.3 * Math.sin(t + p.x * 0.01))
        const col = `hsl(${40 + (200 * (Math.sin((p.x + p.y + t) * 0.001) + 1)) / 2} 70% 60%)`
        ctx.fillStyle = col
        ctx.font = `${p.s}px serif`
        ctx.fillText(p.ch, p.x + 1.2, p.y + 1.2)
        ctx.fillText(p.ch, p.x, p.y)
      }
      ctx.globalAlpha = 1

      // Rotating center glyph (portal)
      const cx = window.innerWidth * 0.5,
        cy = window.innerHeight * 0.45
      ctx.save()
      ctx.translate(cx, cy)
      ctx.rotate(t * 0.5)
      for (let i = 0; i < 8; i++) {
        ctx.rotate((Math.PI * 2) / 8)
        ctx.globalAlpha = 0.9 - i * 0.08
        ctx.font = `${18 + i * 3}px serif`
        ctx.fillStyle = i % 2 ? "#ffd66b" : "#0ea5e9"
        ctx.fillText(glyphs[i % glyphs.length], 120, 0)
      }
      ctx.restore()
    }
    tick()
  }

  const renderContact = () => {
    const contactInfo = document.getElementById("contactInfo")
    if (contactInfo) {
      contactInfo.innerHTML = `واتساب: <strong>+${state.phone}</strong>`
    }
  }

  const renderQR = () => {
    const qrcodeBox = document.getElementById("qrcodeBox")
    if (qrcodeBox) {
      qrcodeBox.innerHTML = ""
      if (typeof window !== "undefined" && window.QRCode) {
        const url = phoneToWhatsAppURL({ offer: "استفسار عام", modeLabel: "روحانية" })
        try {
          new window.QRCode(qrcodeBox, { text: url, width: 110, height: 110 })
        } catch (error) {
          console.log("[v0] QR Code generation failed:", error)
          qrcodeBox.innerHTML = `<div class="w-[110px] h-[110px] bg-slate-800 rounded-lg flex items-center justify-center text-slate-400 text-xs">QR Code</div>`
        }
      } else {
        qrcodeBox.innerHTML = `<div class="w-[110px] h-[110px] bg-slate-800 rounded-lg flex items-center justify-center text-slate-400 text-xs">QR Code</div>`
      }
    }
  }

  const phoneToWhatsAppURL = ({ offer = "استفسار", modeLabel = "روحانية" }) => {
    const txt = `مرحبًا، أود الحجز / الاستفسار عن: ${offer}\nنوع الجولة: ${modeLabel}\nالاسم: \nالتاريخ: \nعدد الأشخاص: `
    return `https://wa.me/${state.phone}?text=${encodeURIComponent(txt)}`
  }

  const fetchAndRenderOffers = async () => {
    // Implementation for fetching and rendering offers
    console.log("[v0] Initializing offers system")
  }

  const handleSaveSettings = () => {
    const phone = document.getElementById("cfgPhone").value
    const csv = document.getElementById("cfgCSV").value
    const aiEndpoint = document.getElementById("cfgAI").value
    setState((prevState) => ({
      ...prevState,
      phone,
      csv,
      aiEndpoint,
    }))
  }

  const handleResetSettings = () => {
    setState({
      phone: "971557119058",
      csv: "https://docs.google.com/spreadsheets/d/e/2PACX-1vT9qkqp2gmx_IIElxTQQiOLF680qe1b4uNhGopZuZhEVxumd-YejBPsHuGiThAWdQzi14hjYAV2rzGb/pub?output=csv",
      aiEndpoint: "",
      offers: [],
      mode: "spiritual",
    })
  }

  return (
    <>
      {/* Portal canvas (visual-only) */}
      <canvas
        id="scene"
        className="fixed left-0 top-0 w-full h-full z-0 pointer-events-none"
        aria-hidden="true"
      ></canvas>

      {/* Settings gear */}
      <div className="fixed right-[18px] bottom-[18px] z-[99]">
        <div
          className="w-14 h-14 rounded-full bg-gradient-to-b from-[#ffd66b] to-[#ffd66b] grid place-items-center cursor-pointer shadow-[0_18px_60px_rgba(0,0,0,0.6)]"
          onClick={() => setSettingsOpen(!settingsOpen)}
          title="Settings"
        >
          ⚙️
        </div>
        {settingsOpen && (
          <div className="fixed right-[86px] bottom-[18px] w-[360px] max-w-[92vw] bg-[#0e1620] rounded-xl p-3 border border-white/[0.04] shadow-[0_30px_120px_rgba(0,0,0,0.7)]">
            <div className="flex justify-between items-center mb-2">
              <strong>Settings</strong>
              <button
                onClick={() => setSettingsOpen(false)}
                className="bg-white/[0.02] border border-white/[0.04] px-2 py-1 rounded-lg text-[#a7b3bd] cursor-pointer"
              >
                Close
              </button>
            </div>
            <div className="flex flex-col gap-2 mb-2">
              <label className="text-sm text-[#a7b3bd]">WhatsApp number (international, no +)</label>
              <input
                id="cfgPhone"
                defaultValue={state.phone}
                placeholder="971551234567"
                className="p-2 rounded-lg border border-white/[0.04] bg-transparent text-[#e7f4fb]"
              />
              <div className="text-xs text-[#a7b3bd]">All booking clicks open WhatsApp to this number.</div>
            </div>
            <div className="flex flex-col gap-2 mb-2">
              <label className="text-sm text-[#a7b3bd]">Google Sheets CSV (public URL)</label>
              <input
                id="cfgCSV"
                defaultValue={state.csv}
                placeholder="https://.../pub?output=csv"
                className="p-2 rounded-lg border border-white/[0.04] bg-transparent text-[#e7f4fb]"
              />
              <div className="text-xs text-[#a7b3bd]">
                Sheet should have columns: id,title,desc,price,duration,active
              </div>
            </div>
            <div className="flex flex-col gap-2 mb-2">
              <label className="text-sm text-[#a7b3bd]">AI API endpoint (optional)</label>
              <input
                id="cfgAI"
                defaultValue={state.aiEndpoint}
                placeholder="https://your-api.example.com/ai"
                className="p-2 rounded-lg border border-white/[0.04] bg-transparent text-[#e7f4fb]"
              />
              <div className="text-xs text-[#a7b3bd]">If filled, chat can use remote AI (optional).</div>
            </div>
            <div className="flex gap-2 justify-end">
              <button
                id="saveSettings"
                onClick={handleSaveSettings}
                className="bg-white/[0.02] border border-white/[0.04] px-2 py-1 rounded-lg text-[#a7b3bd] cursor-pointer"
              >
                Save
              </button>
              <button
                id="resetSettings"
                onClick={handleResetSettings}
                className="bg-white/[0.02] border border-white/[0.04] px-2 py-1 rounded-lg text-[#a7b3bd] cursor-pointer"
              >
                Reset
              </button>
            </div>
            <div className="mt-2 text-sm text-[#a7b3bd]">
              Changes saved locally in your browser. To have shared control use the Google Sheet (edit rows live).
            </div>
          </div>
        )}
      </div>

      {/* Page top */}
      <div className="p-[18px_28px] relative z-[2]">
        <div className="flex justify-between items-center gap-3 mb-2">
          <div className="flex items-center gap-2">
            <div className="w-11 h-11 rounded-lg bg-gradient-to-br from-[#0ea5e9] to-[#22d3ee] grid place-items-center font-black text-[#021521]">
              𓂀
            </div>
            <div>
              <div className="font-extrabold">جولة الأهرامات – نزلة السمان</div>
              <div className="text-xs text-[#a7b3bd]">احجز عبر واتساب مباشرة — تواصل فوري</div>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              id="refreshOffers"
              onClick={fetchAndRenderOffers}
              className="bg-white/[0.02] border border-white/[0.04] px-2 py-1 rounded-lg text-[#a7b3bd] cursor-pointer"
            >
              تحديث العروض
            </button>
            <button
              id="openQR"
              onClick={renderQR}
              className="bg-white/[0.02] border border-white/[0.04] px-2 py-1 rounded-lg text-[#a7b3bd] cursor-pointer"
            >
              عرض QR
            </button>
          </div>
        </div>
      </div>

      {/* Main layout */}
      <div className="min-h-screen grid grid-cols-[1fr_380px] gap-5 p-7 items-start relative z-[2] lg:grid-cols-1 lg:p-4">
        <main className="max-w-[1100px] mx-auto lg:order-1">
          <section className="bg-gradient-to-b from-white/[0.02] to-white/[0.01] rounded-[14px] p-[18px] border border-white/[0.04] shadow-[0_10px_40px_rgba(0,0,0,0.6)]">
            <h1 className="m-0 mb-2 text-[22px]">تجربة أصيلة مع جيران خوفو وخفرع</h1>
            <p className="text-[#a7b3bd] m-0 mb-[14px]">
              ركوب جمل/حصان، باجي/ATV، جولة كاملة، تصوير وضيافة بدوية — احجز الآن عبر واتساب. أثناء انتظار الحجز: تفاعل
              مع البوابة(الهرم) واستمتع بالحروف الطائرة.
            </p>

            <div className="flex gap-2 flex-wrap mb-3" id="summaryChips" aria-hidden="true">
              <div className="px-3 py-2 rounded-full bg-white/[0.02] border border-white/[0.03] font-bold text-[#a7b3bd]">
                📍 نزلة السمان
              </div>
              <div className="px-3 py-2 rounded-full bg-white/[0.02] border border-white/[0.03] font-bold text-[#a7b3bd]">
                ⏱ 60–150 دقيقة
              </div>
              <div className="px-3 py-2 rounded-full bg-white/[0.02] border border-white/[0.03] font-bold text-[#a7b3bd]">
                🎥 تصوير HD
              </div>
            </div>

            <div className="flex gap-2 my-3" role="radiogroup" aria-label="Choose mode">
              <button
                className={`px-3 py-2 rounded-lg border border-white/[0.04] cursor-pointer font-extrabold ${mode === "spiritual" ? "bg-gradient-to-r from-[#0ea5e9] to-[#60c0f4] text-[#001827]" : "bg-transparent text-[#a7b3bd]"}`}
                onClick={() => setMode("spiritual")}
              >
                روحانية 🔵
              </button>
              <button
                className={`px-3 py-2 rounded-lg border border-white/[0.04] cursor-pointer font-extrabold ${mode === "adventure" ? "bg-gradient-to-r from-[#0ea5e9] to-[#60c0f4] text-[#001827]" : "bg-transparent text-[#a7b3bd]"}`}
                onClick={() => setMode("adventure")}
              >
                مغامرة 🔴
              </button>
            </div>

            <div
              className="grid grid-cols-[repeat(auto-fit,minmax(240px,1fr))] gap-[14px] mt-3"
              id="offersGrid"
              aria-live="polite"
            >
              {/* offers injected here from CSV */}
            </div>

            <div className="mt-2 text-sm text-[#a7b3bd]">
              كل زرّ "احجز" يفتح WhatsApp إلى رقمك — يمكنك تعديل الرقم من ⚙️ Settings أو بتعديل Google Sheet مباشرة.
            </div>
            <footer className="mt-[18px] text-[#a7b3bd] text-sm text-center">© نزلة السمان — AlArab Club 777</footer>
          </section>
        </main>

        <aside className="w-full max-w-[380px] sticky top-5 self-start lg:order-2">
          <div className="bg-gradient-to-b from-white/[0.02] to-white/[0.01] p-[14px] rounded-xl border border-white/[0.04] shadow-[0_10px_40px_rgba(0,0,0,0.6)]">
            <div className="rounded-lg overflow-hidden border border-white/[0.03] mb-3">
              <div className="w-full h-48 bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center text-slate-400">
                <div className="text-center">
                  <div className="text-2xl mb-2">🎥</div>
                  <div className="text-sm">فيديو ترويجي للجولات</div>
                  <div className="text-xs mt-1">سيتم إضافة الفيديو قريباً</div>
                </div>
              </div>
            </div>

            <div className="flex gap-2 items-center justify-between mb-2">
              <div>
                <div className="font-extrabold">احجز عبر QR</div>
                <div className="text-sm">امسح الكود لفتح واتساب برسالة جاهزة</div>
              </div>
              <div id="qrcodeBox"></div>
            </div>

            <div className="mt-2 flex gap-2 items-center justify-between">
              <a
                id="whatsappMain"
                className="inline-block mt-2 px-3 py-2 rounded-lg bg-gradient-to-r from-[#0ea5e9] to-[#60c0f4] text-[#021521] no-underline font-extrabold border-0 cursor-pointer"
                href="#"
                target="_blank"
                rel="noreferrer noopener"
              >
                حجز فوري
              </a>
              <button
                id="shareNow"
                className="bg-white/[0.02] border border-white/[0.04] px-2 py-1 rounded-lg text-[#a7b3bd] cursor-pointer"
              >
                مشاركة
              </button>
            </div>

            <div className="mt-3">
              <div className="font-bold mb-1">تفاصيل التواصل</div>
              <div id="contactInfo" className="text-xs text-[#a7b3bd]">
                واتساب: يتم جلبه من الإعدادات
              </div>
              <div className="mt-2 text-sm text-[#a7b3bd]">
                لتحرير العروض مباشرة: عدّل جداول Google Sheets (CSV العام) وسيتم تحديث الموقع مباشرة بعد الضغط على "تحديث
                العروض".
              </div>
            </div>
          </div>
        </aside>
      </div>

      {/* QR lib */}
      <Script
        src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"
        onLoad={() => {
          console.log("[v0] QR Code library loaded")
          renderQR()
        }}
        onError={() => {
          console.log("[v0] QR Code library failed to load")
        }}
      />

      {/* Main JavaScript functionality */}
      <Script
        id="portal-script"
        dangerouslySetInnerHTML={{
          __html: `
          // Portal initialization will be handled by the initializePortal function
        `,
        }}
      />
    </>
  )
}
