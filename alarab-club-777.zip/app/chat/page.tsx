"use client"

import { useState, useEffect } from "react"

const ChatPage = () => {
  const [message, setMessage] = useState("")
  const [reply, setReply] = useState("")
  const [debug, setDebug] = useState("")
  const [tours, setTours] = useState([])

  useEffect(() => {
    loadTours()
  }, [])

  const sendMessage = async () => {
    setReply("جاري الإرسال...")
    setDebug("")

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ message: message || "السلام عليكم" }),
      })

      const ct = res.headers.get("content-type") || ""

      if (ct.includes("application/json")) {
        const data = await res.json()
        if (!res.ok) {
          setReply("خطأ: " + (data.error || res.statusText))
          setDebug(JSON.stringify(data, null, 2))
          return
        }
        setReply(data.reply || JSON.stringify(data))
      } else {
        const txt = await res.text()
        setReply("الرد ليس JSON — عرض نصي للرد:\n" + txt.slice(0, 2000))
        setDebug(`Response status: ${res.status}\nContent-Type: ${ct}\n\nPreview:\n${txt.slice(0, 2000)}`)
      }
    } catch (err) {
      setReply("خطأ في الاتصال: " + err.message)
    }
  }

  const loadTours = async () => {
    try {
      const res = await fetch("/api/tours")
      const data = await res.json()
      setTours(data.tours || [])
    } catch (e) {
      console.warn("Failed to load tours", e)
    }
  }

  return (
    <html lang="ar" dir="rtl">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Final Giza Portal — Test UI</title>
        <style>
          {`
            body { font-family: system-ui, 'Noto Sans Arabic', sans-serif; background: #0b0b0c; color: #fff; padding: 24px; }
            .wrap { max-width: 900px; margin: 0 auto; }
            .card { background: rgba(255, 255, 255, 0.03); padding: 18px; border-radius: 12px; margin-bottom: 16px; }
            input[type=text] { width: 70%; padding: 10px; border-radius: 8px; border: 1px solid rgba(255, 255, 255, 0.06); background: transparent; color: #fff; }
            button { padding: 10px 14px; border-radius: 8px; border: 0; background: #f5c518; color: #111; font-weight: 700; cursor: pointer; }
            #reply { white-space: pre-wrap; margin-top: 12px; color: #dbeafe; }
            ul { list-style: none; padding: 0; }
            li { padding: 8px 0; border-bottom: 1px dashed rgba(255, 255, 255, 0.03); }
            .debug { font-size: 12px; color: #f8d7da; background: #3b0b0b; padding: 8px; border-radius: 8px; margin-top: 8px; }
          `}
        </style>
      </head>
      <body>
        <div className="wrap">
          <h1>بوابة نزلة السمان — اختبار الدردشة</h1>
          <div className="card">
            <label htmlFor="msg">اكتب رسالة للمساعد:</label>
            <br />
            <input
              id="msg"
              type="text"
              placeholder="مثال: ما هي أفضل جولة لقضاء 3 ساعات؟"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />
            <button id="send" onClick={sendMessage}>
              إرسال
            </button>
            <div id="reply">{reply}</div>
            <div id="debug" className="debug" style={{ display: debug ? "block" : "none" }}>
              {debug}
            </div>
          </div>

          <div className="card">
            <h3>العروض المتاحة</h3>
            <ul id="tourList">
              {tours.map((t) => (
                <li key={t.Name}>
                  {t.Name} – {t.Description} |{" "}
                  <a href={`https://wa.me/${t.Phone}`} target="_blank" rel="noreferrer">
                    📲 احجز عبر واتساب
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <small>
            ملاحظات: تأكد من وجود ملف <code>.env</code> يحوي <code>OPENAI_API_KEY=sk-...</code>. إذا كنت تستخدم Node
            &lt;18، ثبّت <code>node-fetch</code> عبر <code>npm i node-fetch</code>.
          </small>
        </div>
      </body>
    </html>
  )
}

export default ChatPage
